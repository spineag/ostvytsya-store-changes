<?php
// Heading
$_['heading_title'] = 'Ostvytsya Theme';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the Ostvytsya theme!';
$_['text_edit'] = 'Edit Ostvytsya Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Ostvytsya theme!';
