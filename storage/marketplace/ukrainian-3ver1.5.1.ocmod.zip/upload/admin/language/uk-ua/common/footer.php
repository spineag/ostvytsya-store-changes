<?php
// Text
$_['text_footer'] 	= '<HR>&copy; 2009-' . date('Y') . ' Всі права захищені.<br> <BR> <a href="https://proplat.biz" target="_blank" class="btn btn-primary">РОЗРОБКА І ПРОСУВАННЯ МАГАЗИНІВ НА OPENCART - PROPLAT.BIZ</a>';
$_['text_version'] 	= 'Version %s (trs-3)';

