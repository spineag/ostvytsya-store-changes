<?php
$_['heading_title'] = 'Google Analytics';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_signup'] = 'Увійдіть в <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> аккаунт і після створення профілю сайту, скопіювати, а потім вставити код в дане поле.';
$_['text_default'] = 'За замовчуванням';
$_['text_edit'] = 'Налаштування модуля';

// Entry
$_['entry_code'] = 'Код Google Analytics';
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даним модулем!';
$_['error_code'] = 'Код необхідний!';
