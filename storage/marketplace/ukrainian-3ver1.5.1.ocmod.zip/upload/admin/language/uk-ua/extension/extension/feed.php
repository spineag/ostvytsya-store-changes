<?php
// Heading
$_['heading_title'] = 'Канали просування';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Список каналів';

// Column
$_['column_name'] = 'Назва каналу';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни каналу товарів!';