<?php
// Heading
$_['heading_title'] = 'Клієнтів';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Налаштування';
$_['text_view'] = 'детальніше...';

// Entry
$_['entry_width'] = 'Ширина';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даними розширенням!';