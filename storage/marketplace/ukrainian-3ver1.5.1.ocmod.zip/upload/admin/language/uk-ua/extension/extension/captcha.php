<?php
// Heading
$_['heading_title'] = 'Захист від роботів';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Список';

// Column
$_['column_name'] = 'Назва';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни каналу товарів!';