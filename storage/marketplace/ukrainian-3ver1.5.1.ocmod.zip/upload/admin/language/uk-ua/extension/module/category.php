<?php
// Heading
$_['heading_title'] = 'Категорії';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Налаштування модуля';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даним модулем!';