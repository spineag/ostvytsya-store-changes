<?php
// Heading
$_['heading_title'] = 'Зовнішні завантаження';

// Text
$_['text_success'] = 'Виконано!';
$_['text_list'] = 'Зовнішні завантаження';

// Column
$_['column_name'] = 'Назва Файлу';
$_['column_filename'] = 'Ім&#39;я Файлу';
$_['column_date_added'] = 'Дата додавання';
$_['column_action'] = 'Дія';

// Entry
$_['entry_name'] = 'Назва Файлу';
$_['entry_filename'] = 'Ім&#39;я Файлу';
$_['entry_date_added'] = 'Дата додавання';

// Error
$_['error_permission'] = 'У Вас немає прав для управління даним модулем!';