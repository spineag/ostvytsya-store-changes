<?php
// Heading
$_['heading_title'] = 'Звіт по кредиту клієнтів';

// Column
$_['text_list'] = 'Кредити клієнтів';
$_['column_customer'] = 'Ім&#39;я клієнта';
$_['column_email'] = 'E-Mail';
$_['column_customer_group'] = 'Група клієнта';
$_['column_status'] = 'Статус';
$_['column_total'] = 'Разом';
$_['column_action'] = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
$_['entry_customer'] = 'Клієнт';