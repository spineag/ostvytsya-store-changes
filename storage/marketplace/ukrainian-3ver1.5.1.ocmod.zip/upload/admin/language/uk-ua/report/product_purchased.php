<?php
// Heading
$_['heading_title'] = 'Звіт по придбаних товарах';

// Text
$_['text_list'] = 'Куплені товари';
$_['text_all_status'] = 'Всі статуси';

// Column
$_['column_date_start'] = 'Дата';
$_['column_date_end'] = 'Дата закінчення';
$_['column_name'] = 'Назва товару';
$_['column_model'] = 'Модель';
$_['column_quantity'] = 'Кількість';
$_['column_total'] = 'Разом';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
$_['entry_status'] = 'Статус замовлення';