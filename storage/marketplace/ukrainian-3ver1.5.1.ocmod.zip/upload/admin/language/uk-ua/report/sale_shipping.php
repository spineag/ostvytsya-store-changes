<?php
// Heading
$_['heading_title'] = 'Звіт по доставках';

// Text
$_['text_list'] = 'Звіт по доставках';
$_['text_year'] = 'Рік';
$_['text_month'] = 'Місяці';
$_['text_week'] = 'Тиждень';
$_['text_day'] = 'День';
$_['text_all_status'] = 'Всі статуси';

// Column
$_['column_date_start'] = 'Дата';
$_['column_date_end'] = 'Дата закінчення';
$_['column_title'] = 'Назва доставки';
$_['column_orders'] = 'Кількість замовлень';
$_['column_total'] = 'Разом';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
$_['entry_group'] = 'Сортувати по';
$_['entry_status'] = 'Статус замовлення';