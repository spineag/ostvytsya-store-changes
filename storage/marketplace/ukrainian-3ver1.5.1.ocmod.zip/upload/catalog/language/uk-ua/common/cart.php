<?php
// Text
$_['text_items']               = '%s товар(ів) - %s';
$_['text_empty'] = 'Ваш кошик порожній!';
$_['text_cart'] = 'Перейти до кошику';
$_['text_checkout'] = 'Оформити замовлення';
$_['text_recurring'] = 'Платіжний профіль';