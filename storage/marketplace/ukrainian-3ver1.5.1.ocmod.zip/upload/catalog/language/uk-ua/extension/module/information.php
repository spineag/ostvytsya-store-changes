<?php
// Heading
$_['heading_title'] = 'Інформація';

// Text
$_['text_contact'] = 'Зв&#39;язатися з нами';
$_['text_sitemap'] = 'Карта сайту';