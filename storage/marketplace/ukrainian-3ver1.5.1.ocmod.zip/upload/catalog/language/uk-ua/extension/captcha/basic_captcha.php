<?php
// Heading
$_['text_captcha'] = 'Захист від роботів';

// Entry
$_['entry_captcha'] = 'Введіть код в поле нижче';

// Error
$_['error_captcha'] = 'код перевірки не співпадає із зображенням!';