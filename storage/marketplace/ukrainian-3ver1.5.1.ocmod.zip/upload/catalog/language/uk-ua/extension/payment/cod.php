<?php
// Text
$_['text_title'] = 'Оплата при доставці';