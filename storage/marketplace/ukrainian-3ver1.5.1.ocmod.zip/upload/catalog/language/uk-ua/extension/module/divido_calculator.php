<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Calculator
$_['text_checkout_title']      = 'Оплата в рассрочку';
$_['text_choose_plan']         = 'Выберите свой план';
$_['text_choose_deposit']      = 'Выберите свой депозит';
$_['text_monthly_payments']    = 'ежемесячные выплаты';
$_['text_months']              = 'месяцы';
$_['text_term']                = 'Срок';
$_['text_deposit']             = 'Депозит';
$_['text_credit_amount']       = 'Стоимость кредита';
$_['text_amount_payable']      = 'Итого к оплате';
$_['text_total_interest']      = 'Общий размер процентов';
$_['text_monthly_installment'] = 'Ежемесячный платеж';
$_['text_redirection']         = 'Вы будете перенаправлены на Менеджера, чтобы завершить эту финансовую заявку, когда вы подтвердите свой заказ';
