<?php
// Text
$_['text_subject'] = '%s - відгук про товар';
$_['text_waiting'] = 'Нові відгуки чекають вашої перевірки .';
$_['text_product'] = 'Товар: %s';
$_['text_reviewer'] = 'залишив Відгук: %s';
$_['text_rating'] = 'Оцінка: %s';
$_['text_review'] = 'Відгук:';